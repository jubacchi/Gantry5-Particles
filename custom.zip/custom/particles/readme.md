This particle intagrates AddThis Social Share 

http://www.addthis.com/
